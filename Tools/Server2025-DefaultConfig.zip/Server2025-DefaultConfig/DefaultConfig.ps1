﻿Start-Transcript $PSScriptRoot
Clear-Host

################################################################################################
################################################################################################

# Check ob Server in Domain

if (((Get-WmiObject Win32_ComputerSystem).Domain).Equals("WORKGROUP")) {
    Write-Host -ForegroundColor Red "Kein Mitglied einer Domäne!"
    $inputDomainSkip = Read-Host -Prompt "Soll das Skript trotzdem gestartet werden? (Y/N)... "
    if($inputDomainSkip.ToLower().Equals("n")){
        exit
    }
    Write-Host -ForegroundColor Green "Nicht in Domain, aber Skript wird fortsetzt."
} else {
    Write-Host -ForegroundColor Green "Server ist in einer Domäne"
}

################################################################################################
################################################################################################


###### Dienste zum abschalten
$DefaultServices = @("Spooler","Audiosrv","AudioEndpointBuilder")


###### Firewall Regeln zum ABSCHALTEN
$TurnOFFFirewallRules = @(
"AllJoyn-Router (TCP eingehend)“,
"AllJoyn-Router (TCP ausgehend)“,
"AllJoyn-Router (UDP eingehend)“,
"AllJoyn-Router (UDP ausgehend)“,
'"Wiedergabe auf Gerät"-Funktionalität (qWave-TCP eingehend)',
'"Wiedergabe auf Gerät"-Funktionalität (qWave-TCP ausgehend)',
'"Wiedergabe auf Gerät"-Funktionalität (qWave-UDP eingehend)',
'"Wiedergabe auf Gerät"-Funktionalität (qWave-UDP ausgehend)',
'"Wiedergabe auf Gerät"-SSDP-Suche (UDP eingehend)',
'"Wiedergabe auf Gerät"-Streamingserver (HTTP-Streaming eingehend)',
'"Wiedergabe auf Gerät"-Streamingserver (RTCP-Streaming eingehend)',
'"Wiedergabe auf Gerät"-Streamingserver (RTP-Streaming ausgehend)',
'"Wiedergabe auf Gerät"-Streamingserver (RTSP-Streaming eingehend)',
'"Wiedergabe auf Gerät"-UPnP-Ereignisse (TCP eingehend)',
„DIAL-Protokollserver (HTTP-In)“,
„mDNS (UDP eingehend)“,
'Microsoft Media Foundation-Netzwerkquelle IN [TCP 554]',
'Microsoft Media Foundation-Netzwerkquelle IN [UDP 5004-5009]',
"OpenSSH SSH Server (sshd)",
'WFD ASP Coordination Protocol (UDP-In)',
'Drahtlose Anzeige (TCP eingehend)',
'Backchannel der Infrastruktur für drahtlose Anzeigen (TCP eingehend)',
'WFD ASP Coordination Protocol (UDP-In)',
'Nur WFD-Treiber (TCP eingehend)',
'Nur WFD-Treiber (UDP eingehend)'
)

###### Firewall Regeln zum EINSCHALTEN

$TurnONFirewallRules = @(
'Datei- und Druckerfreigabe (Echoanforderung - ICMPv4 eingehend)',
'Datei- und Druckerfreigabe (Echoanforderung - ICMPv6 eingehend)'
)


################################################################################################
################################################################################################

# Services Stoppen und StartType auf Deaktiviert setzen um ein Starten zu verhindern

ForEach($DService in $DefaultServices)
{
    Get-Service $DService | Stop-Service 
    Get-Service $DService | Set-Service -StartupType Disabled
}

################################################################################################
################################################################################################

# Firewallregeln aktivieren und deaktivieren je nach angebenen Regeln in den Variablen

foreach ($OFFFirewallRule in $TurnOFFFirewallRules) {
 Get-NetFirewallRule -Displayname $OFFFirewallRule | Set-NetFirewallRule -Enabled:false
}

foreach ($ONFirewallRule in $TurnONFirewallRules) {
 Get-NetFirewallRule -Displayname $ONFirewallRule | Set-NetFirewallRule -Enabled:true
}

################################################################################################
################################################################################################

# RDP Aktivieren

#Set-ItemProperty ‘HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\‘ -Name “fDenyTSConnections” -Value 0
#Set-ItemProperty ‘HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\‘ -Name “UserAuthentication” -Value 1
#Enable-NetFirewallRule -DisplayGroup “Remotedesktop - Benutzermodus (TCP eingehend)”
#Enable-NetFirewallRule -DisplayGroup "Remotedesktop - Benutzermodus (UDP eingehend)"
#Enable-NetFirewallRule -DisplayGroup "Remotedesktop - Schatten (TCP eingehend)"s



################################################################################################
################################################################################################

# Lokalen Admin deaktivieren und umbenennen

Add-Type -AssemblyName System.DirectoryServices.AccountManagement
$PrincipalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine, $env:computername)
$UserPrincipal = New-Object System.DirectoryServices.AccountManagement.UserPrincipal($PrincipalContext)
$Searcher = New-Object System.DirectoryServices.AccountManagement.PrincipalSearcher
$Searcher.QueryFilter = $UserPrincipal
$LocalAdmin = $Searcher.FindAll() | Where-Object {$_.Sid -Like "*-500"} #| Select-Object SamAccountName,Sid
Disable-LocalUser $LocalAdmin
Rename-LocalUser -Name $LocalAdmin -NewName "DoNotUseMe" 

################################################################################################
################################################################################################

# Erstelle neuen lokalen Admin

$Password = Read-Host -AsSecureString "Bitte Password fuer neuen lokalen Admin eingeben:"

New-LocalUser "HohesTier" -Password $Password -FullName "HohesTier" -Description "New Default Local Admin"
Write-Verbose "HohesTier local user crated"
Add-LocalGroupMember -Group "Administratoren" -Member "HohesTier"
Set-LocalUser "HohesTier" -PasswordNeverExpires $true

################################################################################################
################################################################################################

# Task fuer Start des Server-Managers fuer alle deaktivieren
Get-ScheduledTask -TaskName ServerManager | Disable-ScheduledTask

################################################################################################
################################################################################################

# Intalliere Modul zur Installation der Security Baseline

<#
For domain-joined device, run         Set-OSConfigDesiredConfiguration -Scenario SecurityBaseline\WS2025\MemberServer -Default
For workgroup device, run             Set-OSConfigDesiredConfiguration -Scenario SecurityBaseline\WS2025\WorkgroupMember -Default
For domain controller device, run     Set-OSConfigDesiredConfiguration -Scenario SecurityBaseline/WS2025/DomainController -Default
For Secured-core, Run                 Set-OSConfigDesiredConfiguration -Scenario SecuredCore -Default
For Defender Antivirus, Run           Set-OSConfigDesiredConfiguration -Scenario Defender\Antivirus -Default
Restart machine

#>

Install-Module -Name Microsoft.OSConfig
Set-OSConfigDesiredConfiguration -Scenario SecurityBaseline\WS2025\MemberServer -Default

Stop-Transcript
